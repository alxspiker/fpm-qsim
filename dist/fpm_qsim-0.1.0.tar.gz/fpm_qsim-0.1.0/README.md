# fpm-qsim

**Drop-in Lindblad dephasing simulator backed by the Finite Possibility Mechanics affine map.**

`fpm-qsim` is a small, dependency-light Python package that lets you
simulate open-system quantum dephasing dynamics using the FPM affine
coherence map.  The map

```
c_{t+1} = kappa_t * c_t + nu_t
```

is **algebraically identical** to the Euler discretization of the
Lindblad master equation for a dephasing channel with `H = 0`:

```
rho_{t+1} = (1 - gamma*dt) * rho_t + gamma*dt * diag(rho_t)
```

under the identification `gamma_t = (1 - kappa_t) / dt`.  This
correspondence is Theorem 3 of the FPM paper, and is verified
numerically to machine precision (**RMSE 6.13 × 10⁻¹⁷** on
off-diagonal density-matrix elements over 600 ticks and 10 random
paths — see `examples/02_lindblad_comparison.py`).

Because the FPM map is a single vectorized affine update — no matrix
exponentials, no Kraus decomposition — it is typically 5–10× faster
than standard Lindblad integrators for dephasing-dominated dynamics,
while producing numerically identical results.

---

## Installation

```bash
pip install fpm-qsim
```

From source:

```bash
git clone https://github.com/alxspiker/fpm-qsim.git
cd fpm-qsim
pip install -e .
```

**Requirements:** Python ≥ 3.9, NumPy ≥ 1.22.  SciPy and matplotlib
are optional (for tests and examples respectively).

---

## Quick start

```python
import numpy as np
import fpm_qsim as fpm

# Start in the |+><+| state (maximal coherence).
rho0 = fpm.pure_state([1, 1])

# Apply one dephasing step.
rho1 = fpm.lindblad_step(rho0, gamma=0.1, dt=1.0)

# Off-diagonal coherence contracts by (1 - gamma*dt):
assert np.isclose(abs(rho1[0, 1]), 0.9 * abs(rho0[0, 1]))

# Roll out a full trajectory.
traj = fpm.simulate(rho0, gamma=0.05, dt=1.0, n_steps=200)
assert traj.shape == (201, 2, 2)
```

### Drop-in replacement

If you have an existing Lindblad dephasing loop, swap one import:

```python
# Before
# from your_qsim_library import lindblad_step
# rho = lindblad_step(rho, H=None, c_ops=[sqrt(gamma) * sigma_z], dt=0.1)

# After
from fpm_qsim import lindblad_step
rho = lindblad_step(rho, gamma=gamma, dt=0.1)
```

---

## API reference

### Core FPM primitives (`fpm_qsim.core`)

| Symbol | Description |
|---|---|
| `GAMMA_MAX = 31.8738...` | Falsifiable Lorentz-factor ceiling derived from the finite-lag theorem. |
| `FALSIFICATION_THRESHOLD = 32.0` | Observations above this falsify FPM. |
| `ENERGY_FLOOR_FRACTION = 0.03138...` | v5.0 zero-energy floor (Test 07). |
| `ISOTROPIC_WEIGHT_LIMIT = 1/3` | Spectral-gap isotropic limit weight (Test 04). |
| `kappa_from_gamma(gamma, dt=1.0)` | Convert a dephasing rate to the FPM contraction coefficient. |
| `gamma_from_kappa(kappa, dt=1.0)` | Inverse of `kappa_from_gamma`. |
| `fpm_affine_step(c, kappa, nu=0.0)` | One tick of the affine map `c_{t+1} = kappa*c_t + nu`. |
| `fpm_affine_trajectory(c0, kappa, nu=0.0, n_steps=1)` | Closed-form rollout of the affine map. |
| `bounded_gamma(gamma_raw, gamma_max=GAMMA_MAX)` | Clip a rate to the ceiling; raise if it would falsify. |
| `FalsificationError` | Raised when an observation would falsify FPM. |

### Lindblad-equivalent API (`fpm_qsim.lindblad`)

| Symbol | Description |
|---|---|
| `lindblad_step(rho, gamma, dt=1.0, *, H=None, bounded=False)` | Advance a density matrix by one FPM-affine (= Lindblad-Euler) step. |
| `simulate(rho0, gamma, dt=1.0, n_steps=1, *, H=None, bounded=False, record=True)` | Roll out a full trajectory. |
| `reference_lindblad_step(rho, gamma, dt=1.0)` | Textbook Euler step (uses `gamma_text = gamma_FPM / 2` convention); for verification only. |

### State utilities (`fpm_qsim.states`)

| Symbol | Description |
|---|---|
| `basis_state(index, dim)` | Computational basis column vector. |
| `pure_state(amplitudes)` | Build `|psi><psi|` from unnormalized amplitudes. |
| `maximally_mixed(dim)` | `I_dim / dim`. |
| `partial_trace(rho, keep, dims)` | Partial trace over a tensor-product Hilbert space. |
| `is_density_matrix(rho, tol=1e-9)` | Validate Hermiticity, trace, positivity. |
| `trace_distance(rho, sigma)` | `0.5 * ||rho - sigma||_1`. |
| `fidelity(rho, sigma)` | Uhlmann fidelity. |

### Closed-universe conservation (`fpm_qsim.conservation`)

| Symbol | Description |
|---|---|
| `DaemonState` | Per-daemon bookkeeping (energy, coherence, cumulative flows). |
| `ConservationLedger` | Closed-universe ledger; tracks `replenish == spend + landauer`. |

---

## The math, in one page

The FPM coherence variable `c_t` evolves under the affine map

```
c_{t+1} = kappa_t * c_t + nu_t
```

where `kappa_t ∈ [0, 1]` is the contraction coefficient and `nu_t`
is a bounded innovation noise (energy-gated to prevent a
thermodynamic leak at zero energy).

**Theorem 3 (Lindblad Correspondence).** The Euler discretization of
the Lindblad master equation for a dephasing channel with `H = 0`,

```
d(rho)/dt = -gamma * (rho - diag(rho))
```

is algebraically equivalent to the FPM affine map under the
identification

```
gamma_t = (1 - kappa_t) / dt      <==>      kappa_t = 1 - gamma_t * dt
```

The Euler step is

```
rho_{t+1} = (1 - gamma*dt) * rho_t + gamma*dt * diag(rho_t)
```

i.e. off-diagonal elements contract by `(1 - gamma*dt)`, while the
diagonal (populations) is a fixed point — exactly the FPM affine map
on the coherence amplitudes.

Numerical verification (paper Test 02):

```
N_paths:           10
T_ticks:           600
RMSE off-diagonal: 6.13e-17
Max abs diff:      4.16e-16
Pearson r:         1.0
Machine precision: verified
```

### The falsifiable ceiling

The finite-lag ceiling theorem (paper Test 09) caps the physically
admissible gamma at

```
gamma_max = 31.8738...
```

The CERN muon (`gamma = 29.3`) sits below this ceiling.  Any
observation of `gamma > 32.0` falsifies the FPM framework.  The
package refuses to silently clip such observations; pass
`bounded=True` to `lindblad_step` and a `FalsificationError` will be
raised — log the observation instead.

---

## Reproducing the paper's tests

The `tests/` directory reproduces four of the paper's numerical
experiments:

| Test file | Paper test | Reference |
|---|---|---|
| `tests/test_lindblad_correspondence.py` | Test 02 | RMSE 6.13e-17 |
| `tests/test_dispersion_contraction.py` | Test 01 | D* = 1.8e-4 |
| `tests/test_conservation.py` | Test 03 | Drift 1.47% |
| `tests/test_bounded_gamma.py` | Test 07 + Test 09 | gamma_max = 31.87 |

Run them with:

```bash
pip install -e ".[test]"
pytest -v
```

---

## Scope and honest limitations

This package implements the FPM ↔ Lindblad correspondence **for pure
dephasing channels with `H = 0`**, which is the regime where Theorem
3 of the paper provides an algebraic identity.

- The `H` parameter on `lindblad_step` extends the integrator to
  non-zero Hamiltonians by composing an Euler unitary kick with the
  dephasing contraction.  This is a standard composition, but the
  exact algebraic correspondence to a closed-form affine map is
  proven only for `H = 0`.  Callers using `H != 0` should validate
  against a reference integrator for their specific use case.
- General Lindblad channels (amplitude damping, depolarizing, etc.)
  are not directly equivalent to the FPM affine map.  Future
  versions may extend the correspondence.
- The `ConservationLedger` is a faithful bookkeeping layer but does
  not, by itself, enforce the semantic-entropy conservation gate
  (paper Section 6.6).  Callers must implement that gate in their
  application logic.

---

## Citation

If you use `fpm-qsim` in published research, please cite:

```bibtex
@misc{spiker2026fpm,
  title  = {Finite Possibility Mechanics: A Unified Information-Theoretic Framework},
  author = {Spiker, Alx},
  year   = {2026},
  note   = {See Theorem 3 (Lindblad Correspondence) and the Finite-Lag-Ceiling Theorem.}
}

@misc{fpm-qsim,
  title  = {fpm-qsim: Drop-in Lindblad dephasing simulator backed by the FPM affine map},
  author = {Spiker, Alx},
  year   = {2026},
  url    = {https://github.com/alxspiker/fpm-qsim},
}
```

---

## License

MIT.  See `LICENSE`.
