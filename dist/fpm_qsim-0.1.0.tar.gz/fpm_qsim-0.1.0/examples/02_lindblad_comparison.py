"""
Example 02: Lindblad correspondence head-to-head.

Compare the FPM affine-map integrator (this package) against the
textbook Euler-discretized Lindblad master equation.  They should
agree to machine precision (~ 1e-17) on off-diagonal density-matrix
elements.

This is the live reproduction of paper Test 02.
"""
import numpy as np

import fpm_qsim as fpm


def main():
    rng = np.random.default_rng(seed=2026)
    dim = 4
    N_paths = 10
    T_ticks = 600
    gamma = 0.01
    dt = 1.0

    rmse_accum = 0.0
    max_abs_diff = 0.0
    n_offdiag = 0

    for _ in range(N_paths):
        # Random initial density matrix.
        psi = rng.standard_normal(dim) + 1j * rng.standard_normal(dim)
        psi /= np.linalg.norm(psi)
        rho0 = np.outer(psi, psi.conj())

        rho_fpm = rho0.copy()
        rho_lind = rho0.copy()

        for _ in range(T_ticks):
            rho_fpm = fpm.lindblad_step(rho_fpm, gamma=gamma, dt=dt)
            # reference_lindblad_step uses the same gamma convention
            # as lindblad_step (see its docstring).
            rho_lind = fpm.reference_lindblad_step(rho_lind, gamma=gamma, dt=dt)

            off_fpm = rho_fpm[~np.eye(dim, dtype=bool)]
            off_lind = rho_lind[~np.eye(dim, dtype=bool)]
            diff = np.abs(off_fpm - off_lind)
            rmse_accum += float(np.sum(diff ** 2))
            max_abs_diff = max(max_abs_diff, float(diff.max()))
            n_offdiag += off_fpm.size

    rmse = np.sqrt(rmse_accum / n_offdiag)
    print(f"N_paths:            {N_paths}")
    print(f"T_ticks:            {T_ticks}")
    print(f"RMSE off-diagonal:  {rmse:.6e}")
    print(f"Max abs difference: {max_abs_diff:.6e}")
    print(f"\nPaper reference:")
    print(f"  RMSE:  6.13e-17")
    print(f"  Max:   4.16e-16")
    print(f"\nVerdict: {'PASS' if rmse < 1e-14 else 'FAIL'}")


if __name__ == "__main__":
    main()
