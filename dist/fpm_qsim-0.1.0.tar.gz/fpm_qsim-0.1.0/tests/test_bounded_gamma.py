"""
Reproduce paper Test 07 (Bounded Asymptotics) and Test 09
(Finite Lag Ceiling).

The bounded-asymptotic theorem caps the FPM gamma at

    gamma_max = 31.8738...

and the finite-lag theorem sets the falsification threshold at

    gamma > 32.0  =>  FPM falsified.

The CERN muon (gamma = 29.3) sits below the ceiling.
"""

import numpy as np
import pytest

import fpm_qsim as fpm
from fpm_qsim.core import GAMMA_MAX, FALSIFICATION_THRESHOLD


def test_gamma_max_value():
    """The derived gamma_max matches the paper."""
    assert abs(GAMMA_MAX - 31.873862947240752) < 1e-12


def test_falsification_threshold():
    """Falsification threshold is 32.0 (rounded ceiling + margin)."""
    assert FALSIFICATION_THRESHOLD == 32.0


def test_cern_muon_in_range():
    """The CERN muon (gamma = 29.3) is below the FPM ceiling."""
    cern_muon_gamma = 29.3
    assert cern_muon_gamma < GAMMA_MAX, (
        "CERN muon gamma exceeds FPM ceiling; framework falsified"
    )


def test_bounded_gamma_clips_at_ceiling():
    """bounded_gamma clips values in [gamma_max, 32.0) down to gamma_max."""
    # 31.95 is above gamma_max (31.8738) but below the falsification
    # threshold (32.0), so it should be clipped to gamma_max.
    assert abs(fpm.bounded_gamma(31.95) - GAMMA_MAX) < 1e-12
    # Anything exactly at gamma_max passes through.
    assert abs(fpm.bounded_gamma(GAMMA_MAX) - GAMMA_MAX) < 1e-12


def test_bounded_gamma_passes_through_below_ceiling():
    """Below gamma_max, bounded_gamma is identity."""
    assert abs(fpm.bounded_gamma(10.0) - 10.0) < 1e-12
    assert abs(fpm.bounded_gamma(0.0) - 0.0) < 1e-12
    assert abs(fpm.bounded_gamma(GAMMA_MAX - 0.01) - (GAMMA_MAX - 0.01)) < 1e-12


def test_falsification_raises():
    """gamma > 32.0 raises FalsificationError."""
    with pytest.raises(fpm.FalsificationError):
        fpm.bounded_gamma(33.0)
    with pytest.raises(fpm.FalsificationError):
        fpm.bounded_gamma(100.0)
    with pytest.raises(fpm.FalsificationError):
        fpm.bounded_gamma(1e6)


def test_bounded_flag_in_lindblad_step():
    """lindblad_step(bounded=True) clips gamma to the ceiling."""
    rho = fpm.pure_state([1, 1])
    # gamma=31.9 should be clipped to GAMMA_MAX via bounded=True.
    # But gamma * dt = 31.9 > 1.0 — that's outside the contractive
    # range, so this should raise ValueError.
    # Use a smaller dt.
    rho_next = fpm.lindblad_step(rho, gamma=31.9, dt=0.01, bounded=True)
    # gamma was clipped to GAMMA_MAX = 31.8738..., so:
    #   kappa = 1 - 31.8738 * 0.01 = 1 - 0.3187 = 0.6813
    expected_kappa = 1 - GAMMA_MAX * 0.01
    assert abs(rho_next[0, 1] - expected_kappa * rho[0, 1]) < 1e-12


def test_falsification_via_lindblad_step():
    """lindblad_step with gamma > 32 (after bounded check) raises."""
    rho = fpm.pure_state([1, 1])
    with pytest.raises(fpm.FalsificationError):
        fpm.lindblad_step(rho, gamma=33.0, dt=0.01, bounded=True)


def test_energy_floor_value():
    """v5.0 energy floor matches the paper Test 07 value."""
    assert abs(fpm.ENERGY_FLOOR_FRACTION - 0.03138766217547228) < 1e-12
