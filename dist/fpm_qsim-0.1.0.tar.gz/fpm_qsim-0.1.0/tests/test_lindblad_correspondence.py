"""
Reproduce paper Test 02: Lindblad Correspondence Theorem.

Asserts that the FPM affine map and the Euler-discretized Lindblad
dephasing master equation agree on off-diagonal density-matrix
elements to machine precision.

Paper reference values:

    N_paths: 10
    T_ticks: 600
    RMSE off-diagonal: 6.13e-17
    Max abs difference: 4.16e-16
    Pearson correlation: 1.0
    Machine precision verified: True
"""

import numpy as np
import pytest

import fpm_qsim as fpm


def _random_density_matrix(dim: int, rng: np.random.Generator) -> np.ndarray:
    """Generate a random valid density matrix via Haar-random pure states
    mixed with a random weight."""
    psi = rng.standard_normal(dim) + 1j * rng.standard_normal(dim)
    psi /= np.linalg.norm(psi)
    rho_pure = np.outer(psi, psi.conj())
    phi = rng.standard_normal(dim) + 1j * rng.standard_normal(dim)
    phi /= np.linalg.norm(phi)
    rho_pure2 = np.outer(phi, phi.conj())
    w = rng.random()
    return w * rho_pure + (1 - w) * rho_pure2


def test_lindblad_correspondence_off_diagonal():
    """The headline test: FPM affine map == Lindblad Euler step.

    Reproduces paper Test 02.  Target: RMSE < 1e-14 on off-diagonal
    elements over 600 ticks and 10 random initial states.
    """
    rng = np.random.default_rng(seed=2026)
    N_paths = 10
    T_ticks = 600
    dim = 4
    gamma = 0.01
    dt = 1.0

    rmse_accum = 0.0
    max_abs_diff = 0.0
    n_offdiag = 0
    all_fpm_offdiag = []
    all_lindblad_offdiag = []

    for _ in range(N_paths):
        rho0 = _random_density_matrix(dim, rng)
        rho_fpm = rho0.copy()
        rho_lind = rho0.copy()

        for _ in range(T_ticks):
            rho_fpm = fpm.lindblad_step(rho_fpm, gamma=gamma, dt=dt)
            rho_lind = fpm.reference_lindblad_step(rho_lind, gamma=gamma, dt=dt)

            # Compare off-diagonal elements only.
            off_fpm = rho_fpm[~np.eye(dim, dtype=bool)]
            off_lind = rho_lind[~np.eye(dim, dtype=bool)]
            diff = np.abs(off_fpm - off_lind)
            rmse_accum += float(np.sum(diff ** 2))
            max_abs_diff = max(max_abs_diff, float(diff.max()))
            n_offdiag += off_fpm.size
            all_fpm_offdiag.extend(off_fpm.real.tolist())
            all_lindblad_offdiag.extend(off_lind.real.tolist())

    rmse = np.sqrt(rmse_accum / n_offdiag)
    # Pearson correlation
    corr = float(np.corrcoef(all_fpm_offdiag, all_lindblad_offdiag)[0, 1])

    # Paper reports RMSE 6.13e-17.  Allow 1e-14 as a safety margin
    # across platforms / numpy versions.
    assert rmse < 1e-14, f"RMSE {rmse:.3e} exceeds 1e-14"
    assert max_abs_diff < 1e-13, f"Max abs diff {max_abs_diff:.3e} too large"
    assert abs(corr - 1.0) < 1e-10, f"Pearson r={corr} != 1.0"

    # Report (visible with `pytest -s`)
    print(f"\n  N_paths:         {N_paths}")
    print(f"  T_ticks:         {T_ticks}")
    print(f"  RMSE off-diag:   {rmse:.6e}")
    print(f"  Max abs diff:    {max_abs_diff:.6e}")
    print(f"  Pearson r:       {corr}")
    print(f"  Verdict:         PASS")


def test_kappa_gamma_round_trip():
    """kappa_from_gamma and gamma_from_kappa are mutual inverses.

    The conversion involves subtracting two near-1 numbers when gamma*dt
    is small (catastrophic cancellation in float64), so we use a
    relative tolerance of 1e-10 which is the best achievable across
    the full parameter range.
    """
    for gamma in [0.0, 0.001, 0.1, 0.5, 0.99]:
        for dt in [0.01, 0.1, 1.0]:
            kappa = fpm.kappa_from_gamma(gamma, dt)
            gamma_back = fpm.gamma_from_kappa(kappa, dt)
            # Float64 precision: when gamma*dt is small, kappa ~ 1 and
            # the round-trip loses ~5 digits to cancellation.
            assert np.isclose(gamma, gamma_back, rtol=1e-10, atol=1e-15), (
                f"round-trip failed: gamma={gamma}, dt={dt}, "
                f"kappa={kappa}, gamma_back={gamma_back}"
            )


def test_diagonal_is_fixed_point():
    """Populations (diagonal) are unchanged by the dephasing step."""
    rng = np.random.default_rng(seed=42)
    for _ in range(5):
        rho = _random_density_matrix(4, rng)
        rho_next = fpm.lindblad_step(rho, gamma=0.3, dt=1.0)
        assert np.allclose(np.diagonal(rho), np.diagonal(rho_next)), (
            "populations changed under dephasing"
        )


def test_trace_preservation():
    """Trace is preserved to machine precision."""
    rng = np.random.default_rng(seed=7)
    for _ in range(5):
        rho = _random_density_matrix(5, rng)
        rho_next = fpm.lindblad_step(rho, gamma=0.2, dt=1.0)
        assert abs(np.trace(rho_next) - 1.0) < 1e-14, (
            f"trace drifted: {np.trace(rho_next)}"
        )


def test_hermiticity_preservation():
    """Output remains Hermitian."""
    rng = np.random.default_rng(seed=11)
    for _ in range(5):
        rho = _random_density_matrix(4, rng)
        rho_next = fpm.lindblad_step(rho, gamma=0.15, dt=1.0)
        assert np.allclose(rho_next, rho_next.conj().T, atol=1e-14), (
            "output not Hermitian"
        )


def test_invalid_gamma_dt_raises():
    """gamma * dt outside [0, 1] raises ValueError."""
    rho = fpm.pure_state([1, 0])
    with pytest.raises(ValueError):
        fpm.lindblad_step(rho, gamma=2.0, dt=1.0)
    with pytest.raises(ValueError):
        fpm.lindblad_step(rho, gamma=-0.1, dt=1.0)


def test_long_time_decay():
    """After many steps, off-diagonal coherence -> 0 (dephased state)."""
    rho0 = fpm.pure_state([1, 1])  # |+><+|
    traj = fpm.simulate(rho0, gamma=0.05, dt=1.0, n_steps=500)
    rho_final = traj[-1]
    # Off-diagonal should be ~ (1 - 0.05)^500 ~ e^{-25} ~ 1.4e-11
    assert abs(rho_final[0, 1]) < 1e-9, (
        f"coherence did not decay: {rho_final[0, 1]}"
    )
    # Diagonal should be ~ [0.5, 0.5]
    assert abs(rho_final[0, 0].real - 0.5) < 1e-9
    assert abs(rho_final[1, 1].real - 0.5) < 1e-9
