# CHANGES

## 0.1.0 (2026-06-17)

Initial release.

- Core FPM affine map primitives (`fpm_affine_step`,
  `fpm_affine_trajectory`, `kappa_from_gamma`, `gamma_from_kappa`).
- Drop-in Lindblad dephasing API (`lindblad_step`, `simulate`,
  `reference_lindblad_step`).
- Bounded gamma form with falsifiable ceiling (`bounded_gamma`,
  `FalsificationError`).
- Density matrix utilities (`pure_state`, `maximally_mixed`,
  `partial_trace`, `is_density_matrix`, `trace_distance`,
  `fidelity`).
- Closed-universe conservation ledger (`ConservationLedger`,
  `DaemonState`).
- Tests reproducing paper Test 01, Test 02, Test 03, Test 07, and
  Test 09.
- Usage examples (basic dephasing, Lindblad correspondence,
  bounded gamma, multi-qubit partial trace).
