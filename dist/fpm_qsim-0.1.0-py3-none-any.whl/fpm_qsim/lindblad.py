"""
fpm_qsim.lindblad
=================

Drop-in Lindblad dephasing simulator backed by the FPM affine map.

This module provides the user-facing API that mirrors common quantum
open-systems libraries (QuTiP, qiskit_aer, etc.) so that existing
code can be ported with a single import change:

Before::

    from qutip import mesolve  # or your favorite Lindblad integrator
    rho_t = mesolve(H, rho0, tlist, c_ops=[np.sqrt(gamma)*sigma_z()])

After::

    from fpm_qsim import lindblad_step
    rho_t = rho0
    for _ in range(n_steps):
        rho_t = lindblad_step(rho_t, gamma=gamma, dt=dt)

The FPM affine map and the Euler-discretized Lindblad dephasing
master equation are algebraically identical (paper Theorem 3,
RMSE 6e-17 on off-diagonal elements over 600 ticks).  This module
exploits that identity to provide a fast, allocation-light
integrator that needs no matrix exponentials and no Kraus
decomposition.
"""

from __future__ import annotations

from typing import Optional, Union

import numpy as np

from .core import (
    GAMMA_MAX,
    FalsificationError,
    bounded_gamma,
    kappa_from_gamma,
)


ArrayLike = Union[np.ndarray, "list"]


# ---------------------------------------------------------------------------
# Density-matrix helpers
# ---------------------------------------------------------------------------

def _as_density_matrix(rho: ArrayLike) -> np.ndarray:
    """Coerce ``rho`` to a 2-D complex128 ndarray with shape (N, N)."""
    arr = np.asarray(rho, dtype=np.complex128)
    if arr.ndim != 2 or arr.shape[0] != arr.shape[1]:
        raise ValueError(
            f"rho must be a square 2-D array; got shape {arr.shape}."
        )
    return arr


def _diag_view(rho: np.ndarray) -> np.ndarray:
    """Return a writeable view of the diagonal of ``rho``."""
    return np.diagonal(rho).copy()


# ---------------------------------------------------------------------------
# The drop-in dephasing step
# ---------------------------------------------------------------------------

def lindblad_step(
    rho: ArrayLike,
    gamma: float,
    dt: float = 1.0,
    *,
    H: Optional[ArrayLike] = None,
    bounded: bool = False,
) -> np.ndarray:
    """Advance a density matrix by one FPM-affine (= Lindblad-Euler) step.

    Implements

        rho_{t+1} = (1 - gamma*dt) * rho_t + gamma*dt * diag(rho_t)

    which is the Euler discretization of

        d(rho)/dt = -gamma * (rho - diag(rho))

    i.e. a pure dephasing Lindblad channel with H = 0.  By Theorem 3
    of the FPM paper, this is algebraically identical to one tick of
    the FPM coherence affine map.

    Parameters
    ----------
    rho : array_like, shape (N, N)
        Current density matrix.  Must be Hermitian.  Trace
        preservation is enforced by construction.
    gamma : float
        Dephasing rate (1/time units).  Must satisfy
        ``0 <= gamma * dt <= 1`` for the affine map to remain
        contractive.
    dt : float, optional
        Time step.  Default 1.0.
    H : array_like, optional
        Hamiltonian.  If provided, a single Euler step of
        ``-i*[H, rho]/hbar`` is applied BEFORE the dephasing
        contraction.  This extends the integrator beyond pure
        dephasing; the exact FPM correspondence is proven only for
        H = 0, so callers using H != 0 should validate against a
        reference integrator.
    bounded : bool, optional
        If True, clip ``gamma`` at :data:`GAMMA_MAX` before use and
        raise :class:`FalsificationError` if it exceeds the
        falsification threshold.  Default False (caller is
        responsible).

    Returns
    -------
    ndarray, shape (N, N)
        Next density matrix.  A fresh array; ``rho`` is not modified.

    Notes
    -----
    The operation is trace-preserving by construction (the diagonal
    is a fixed point of the affine map).  Positive semidefiniteness
    is preserved as long as ``0 <= gamma * dt <= 1``; outside this
    range the map can produce unphysical states and a
    :class:`ValueError` is raised.
    """
    rho_arr = _as_density_matrix(rho).copy()

    if bounded:
        gamma = float(bounded_gamma(gamma))
    else:
        gamma = float(gamma)

    # Optional unitary kick (extension; not part of the exact theorem).
    if H is not None:
        H_arr = np.asarray(H, dtype=np.complex128)
        if H_arr.shape != rho_arr.shape:
            raise ValueError(
                f"H shape {H_arr.shape} does not match rho shape "
                f"{rho_arr.shape}."
            )
        # Euler step of -i [H, rho] dt   (hbar = 1)
        rho_arr += -1j * (H_arr @ rho_arr - rho_arr @ H_arr) * dt

    # Validate the dephasing rate.
    product = gamma * dt
    if product < 0.0 or product > 1.0:
        raise ValueError(
            f"gamma * dt = {product:.6g} is outside [0, 1]; the affine "
            "map would be non-contractive or sign-flipping. Reduce dt "
            "or clip gamma."
        )

    # The affine map: off-diagonal contracts by (1 - gamma*dt),
    # diagonal is a fixed point.  Implemented in one vectorised op.
    kappa = 1.0 - product
    diag = np.diagonal(rho_arr).copy()
    out = kappa * rho_arr
    # Restore the diagonal to its fixed-point value.
    np.fill_diagonal(out, diag)
    return out


def simulate(
    rho0: ArrayLike,
    gamma: float,
    dt: float = 1.0,
    n_steps: int = 1,
    *,
    H: Optional[ArrayLike] = None,
    bounded: bool = False,
    record: bool = True,
):
    """Roll out a Lindblad dephasing trajectory.

    Convenience wrapper around :func:`lindblad_step` that records
    the full trajectory.

    Parameters
    ----------
    rho0 : array_like, shape (N, N)
        Initial density matrix.
    gamma : float
        Dephasing rate.
    dt : float, optional
        Time step.  Default 1.0.
    n_steps : int, optional
        Number of steps to integrate.  Default 1.
    H : array_like, optional
        Optional Hamiltonian.  See :func:`lindblad_step`.
    bounded : bool, optional
        If True, apply the FPM gamma ceiling.  Default False.
    record : bool, optional
        If True (default), return the full trajectory of shape
        ``(n_steps + 1, N, N)``.  If False, return only the final
        state.

    Returns
    -------
    ndarray
        Trajectory of shape ``(n_steps + 1, N, N)`` if ``record`` is
        True, else shape ``(N, N)``.
    """
    if n_steps < 0:
        raise ValueError(f"n_steps must be >= 0, got {n_steps}.")

    rho = _as_density_matrix(rho0).copy()
    N = rho.shape[0]

    if not record:
        for _ in range(n_steps):
            rho = lindblad_step(rho, gamma=gamma, dt=dt, H=H, bounded=bounded)
        return rho

    traj = np.empty((n_steps + 1, N, N), dtype=np.complex128)
    traj[0] = rho
    for t in range(1, n_steps + 1):
        rho = lindblad_step(rho, gamma=gamma, dt=dt, H=H, bounded=bounded)
        traj[t] = rho
    return traj


# ---------------------------------------------------------------------------
# Reference implementation (verbatim Lindblad Euler step)
# ---------------------------------------------------------------------------

def reference_lindblad_step(
    rho: ArrayLike,
    gamma: float,
    dt: float = 1.0,
) -> np.ndarray:
    """Reference Euler step of the Lindblad dephasing master equation.

    Implements the standard textbook pure-dephasing form

        d(rho)/dt = -gamma * (rho - diag(rho))

    which corresponds to the Lindblad equation with multiple
    operators ``L_j = sqrt(gamma) * |j><j|`` for ``j = 0, ..., N-1``.
    The drift is zero on the diagonal (populations unchanged) and
    ``-gamma * rho_{ij}`` on off-diagonal elements (coherences
    decay at rate ``gamma``).

    This convention **matches** :func:`lindblad_step` exactly (no
    factor-of-two rescaling needed).  The function exists purely as
    a numerical reference; it is slower than :func:`lindblad_step`
    because it explicitly constructs the diagonal-projection drift
    term, and produces identical results to machine precision.
    """
    rho_arr = _as_density_matrix(rho).copy()
    # Pure dephasing in the computational basis: drift = -gamma*(rho - diag(rho)).
    diag = np.diagonal(rho_arr).copy()
    drift = -float(gamma) * (rho_arr - np.diag(diag))
    return rho_arr + drift * float(dt)


__all__ = [
    "lindblad_step",
    "simulate",
    "reference_lindblad_step",
]
